from django.apps import AppConfig


class AdoptaunapatitaappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'AdoptaUnaPatitaApp'
