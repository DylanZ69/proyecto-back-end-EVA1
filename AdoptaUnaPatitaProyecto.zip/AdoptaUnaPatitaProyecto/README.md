Adopta Una Patita - Proyecto Backend EVA1

Descripción
Este proyecto corresponde a la Evaluación 1 de Back-End. 
Se trata de una aplicación web desarrollada con Django que permite gestionar el proceso de adopción de mascotas a través de un sistema de registro de usuarios, gestión de refugios, mascotas y solicitudes de adopción.


Requisitos Previos
Antes de comenzar, asegúrate de tener instalado:
- Python 3.12 o superior  
- Git  
- pip (administrador de paquetes de Python)  


Instalación y Ejecución

Clonar el repositorio

git clone https://github.com/DylanZ69/proyecto-back-end-EVA1.git
cd proyecto-back-end-EVA1/AdoptaUnaPatitaProyecto
seguido de py manage.py runserver
